#!/usr/bin/bash
sudo apt-get install node.js
sudo apt-get install npm
npm install express
sudo -H pip3 install simple-websocket-server
sudo -H pip3 install pyax12
